<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Edit Photo</h1>

    <div class="row">
        <div class="col-md-6">
            <form action="<?php echo e(url('admin/photo-change/update')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="current_photo" value="<?php echo e(Auth::guard('admin')->user()->photo); ?>">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 mt-2 font-weight-bold text-primary">Edit Photo</h6>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Existing Photo *</label>
                            <div>
                                <img src="<?php echo e(asset('uploads/'.Auth::guard('admin')->user()->photo)); ?>" alt="" class="w_150">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Change Photo *</label>
                            <div><input type="file" name="photo"></div>
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </form>        
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/admin/auth/photo_change.blade.php ENDPATH**/ ?>