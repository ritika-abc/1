<div class="sidebar">
    <div class="widget">
        <form action="<?php echo e(url('search')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="search input-group md-form form-sm form-2 pl-0">
                <input name="search_string" class="form-control my-0 py-1 red-border" type="text" placeholder="<?php echo e(SEARCH_BLOG_DOT); ?>">
                <div class="input-group-append">
                    <button type="submit" name="form_search">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
    <div class="widget">
        <h3><?php echo e(CATEGORIES); ?></h3>
        <div class="type-1">
            <ul>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(url('category/'.$row->category_slug)); ?>"><?php echo e($row->category_name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="widget">
        <h3><?php echo e(RECENT_POSTS); ?></h3>
        <div class="type-2">
            <ul>
                <?php $i=0 ?>
                <?php $__currentLoopData = $blog_items_no_pagi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++ ?>
                    <?php if($i > $g_setting->sidebar_total_recent_post): ?>
                        <?php break; ?>
                    <?php endif; ?>
                    <li>
                        <img src="<?php echo e(asset('uploads/'.$row->blog_photo)); ?>">
                        <a href="<?php echo e(url('blog/'.$row->blog_slug)); ?>"><?php echo e($row->blog_title); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/layouts/sidebar_blog.blade.php ENDPATH**/ ?>