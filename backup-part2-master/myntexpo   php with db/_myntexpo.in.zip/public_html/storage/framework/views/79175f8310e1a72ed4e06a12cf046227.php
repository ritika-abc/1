<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Order Detail</h1>

    <div class="row">
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 mt-2 font-weight-bold text-primary">Order Details</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <td>Order Number</td>
                                <td><?php echo e($order_detail->order_no); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping Cost</td>
                                <td><?php echo e($order_detail->shipping_cost); ?></td>
                            </tr>
                            <tr>
                                <td>Coupon Discount</td>
                                <td>$<?php echo e($order_detail->coupon_discount); ?> (CODE: <?php echo e($order_detail->coupon_code); ?>)</td>
                            </tr>
                            <tr>
                                <td>Paid Amount</td>
                                <td>$<?php echo e($order_detail->paid_amount); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 mt-2 font-weight-bold text-primary">Customer & Payment Gateway Details</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <td>Customer Type</td>
                                <td><?php echo e($order_detail->customer_type); ?></td>
                            </tr>
                            <tr>
                                <td>Customer Name</td>
                                <td><?php echo e($order_detail->customer_name); ?></td>
                            </tr>
                            <tr>
                                <td>Customer Email</td>
                                <td><?php echo e($order_detail->customer_email); ?></td>
                            </tr>
                            <tr>
                                <td>Payment Method</td>
                                <td>
                                    <?php echo e($order_detail->payment_method); ?>

                                    <?php if($order_detail->payment_method == 'Stripe'): ?>
                                        <br>
                                        Card Last 4 Digit: <?php echo e($order_detail->card_last4); ?>

                                        <br>
                                        Expiry Month: <?php echo e($order_detail->card_exp_month); ?>

                                        <br>
                                        Expiry Year: <?php echo e($order_detail->card_exp_year); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>Payment Date & Time</td>
                                <td><?php echo e($order_detail->created_at); ?></td>
                            </tr>
                            <tr>
                                <td>Payment Status</td>
                                <td><?php echo e($order_detail->payment_status); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 mt-2 font-weight-bold text-primary">Billing Information</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <td>Billing Name</td>
                                <td><?php echo e($order_detail->billing_name); ?></td>
                            </tr>
                            <tr>
                                <td>Billing Email</td>
                                <td><?php echo e($order_detail->billing_email); ?></td>
                            </tr>
                            <tr>
                                <td>Billing Phone</td>
                                <td><?php echo e($order_detail->billing_phone); ?></td>
                            </tr>
                            <tr>
                                <td>Billing Country</td>
                                <td><?php echo e($order_detail->billing_country); ?></td>
                            </tr>
                            <tr>
                                <td>Billing Address</td>
                                <td><?php echo e($order_detail->billing_address); ?></td>
                            </tr>
                            <tr>
                                <td>Billing State</td>
                                <td><?php echo e($order_detail->billing_state); ?></td>
                            </tr>
                            <tr>
                                <td>Billing City</td>
                                <td><?php echo e($order_detail->billing_city); ?></td>
                            </tr>
                            <tr>
                                <td>Billing Zip</td>
                                <td><?php echo e($order_detail->billing_zip); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 mt-2 font-weight-bold text-primary">Shipping Information</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <td>Shipping Name</td>
                                <td><?php echo e($order_detail->shipping_name); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping Email</td>
                                <td><?php echo e($order_detail->shipping_email); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping Phone</td>
                                <td><?php echo e($order_detail->shipping_phone); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping Country</td>
                                <td><?php echo e($order_detail->shipping_country); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping Address</td>
                                <td><?php echo e($order_detail->shipping_address); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping State</td>
                                <td><?php echo e($order_detail->shipping_state); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping City</td>
                                <td><?php echo e($order_detail->shipping_city); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping Zip</td>
                                <td><?php echo e($order_detail->shipping_zip); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 mt-2 font-weight-bold text-primary">Product Information</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <th>SL</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                                <th>Product Quantity</th>
                                <th>Product Subtotal</th>
                            </tr>
                            <?php $__currentLoopData = $product_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($row->product_name); ?></td>
                                <td>$<?php echo e($row->product_price); ?></td>
                                <td><?php echo e($row->product_qty); ?></td>
                                <td>$<?php echo e($row->product_price * $row->product_qty); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/admin/order/detail.blade.php ENDPATH**/ ?>