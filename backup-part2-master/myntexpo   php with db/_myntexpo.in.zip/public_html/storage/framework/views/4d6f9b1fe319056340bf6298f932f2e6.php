<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_job_application)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e(APPLY_FOR_COLON); ?> <?php echo e($job_detail->job_title); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('front.career')); ?>"><?php echo e(CAREER); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($job_detail->job_title); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="career-sidebar">
                        <div class="widget">
                            <h3><?php echo e(APPLY_IN_THIS_JOB); ?></h3>
                            <div class="type-3">
                                <form action="<?php echo e(route('front.apply_form')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                    <input type="hidden" name="job_id" value="<?php echo e($job_detail->id); ?>">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(FIRST_NAME); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_first_name" value="<?php echo e(old('applicant_first_name')); ?>">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(LAST_NAME); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_last_name" value="<?php echo e(old('applicant_last_name')); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(EMAIL_ADDRESS); ?> *</label>
                                                <input type="email" class="form-control" name="applicant_email" value="<?php echo e(old('applicant_email')); ?>">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(PHONE); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_phone" value="<?php echo e(old('applicant_phone')); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(COUNTRY); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_country" value="<?php echo e(old('applicant_country')); ?>">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(STATE); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_state" value="<?php echo e(old('applicant_state')); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(STREET); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_street" value="<?php echo e(old('applicant_street')); ?>">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(CITY); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_city" value="<?php echo e(old('applicant_city')); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(ZIP_CODE); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_zip_code" value="<?php echo e(old('applicant_zip_code')); ?>">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label><?php echo e(EXPECTED_SALARY); ?> *</label>
                                                <input type="text" class="form-control" name="applicant_expected_salary" value="<?php echo e(old('applicant_expected_salary')); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label><?php echo e(COVER_LETTER); ?> *</label>
                                        <textarea name="applicant_cover_letter" class="form-control h-300" cols="30" rows="10"><?php echo e(old('applicant_cover_letter')); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo e(ATTACH_RESUME); ?> *</label><br>
                                        <input type="file" name="applicant_cv"><br>
                                        <span class="text-danger">(<?php echo e(DOC_DOCX_PDF_ALLOWED); ?>)</span>
                                    </div>

                                    <?php if($g_setting->google_recaptcha_status == 'Show'): ?>
                                        <div class="form-group">
                                            <div class="g-recaptcha" data-sitekey="<?php echo e($g_setting->google_recaptcha_site_key); ?>"></div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="form-group">
                                        <div>
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="customCheck1">
                                                <label class="custom-control-label" for="customCheck1"><?php echo e(AGREE_TEXT); ?></label>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-primary mt_10 button_final" disabled><?php echo e(SUBMIT_APPLICATION); ?></button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $("#customCheck1").on('change',function() {
            if(this.checked)
            {
                $(".button_final").prop('disabled', false);
            }
            else
            {
                $(".button_final").prop('disabled', true);
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/pages/job_apply.blade.php ENDPATH**/ ?>