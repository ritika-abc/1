<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_project)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($project->name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($project->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $project->detail; ?>

                </div>
            </div>
            <div class="row project pt_0 pb_0">
                <?php $__currentLoopData = $project_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="project-item wow fadeInUp mb_30">
                            <div class="photo">
                                <a href="<?php echo e(url('project/'.$row->project_slug)); ?>"><img src="<?php echo e(asset('uploads/'.$row->project_featured_photo)); ?>" alt=""></a>
                            </div>
                            <div class="text">
                                <h3><a href="<?php echo e(url('project/'.$row->project_slug)); ?>"><?php echo e($row->project_name); ?></a></h3>
                                <p><?php echo e($row->project_content_short); ?></p>
                                <div class="read-more">
                                    <a href="<?php echo e(url('project/'.$row->project_slug)); ?>"><?php echo e(READ_MORE); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php echo e($project_items->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/pages/projects.blade.php ENDPATH**/ ?>