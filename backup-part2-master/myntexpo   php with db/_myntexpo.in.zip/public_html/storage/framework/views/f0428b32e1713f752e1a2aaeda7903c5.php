<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_faq)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($faq->name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($faq->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $faq->detail; ?>

                </div>
            </div>
            <div class="row">
                <div class="col-md-12 faq">
                    <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="true">
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="heading<?php echo e($i); ?>">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#collapse<?php echo e($i); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($i); ?>">
                                        <?php echo e($row->faq_title); ?>

                                    </a>
                                </h4>
                            </div>
                            <div id="collapse<?php echo e($i); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($i); ?>">
                                <div class="panel-body">
                                    <?php echo $row->faq_content; ?>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/pages/faq.blade.php ENDPATH**/ ?>