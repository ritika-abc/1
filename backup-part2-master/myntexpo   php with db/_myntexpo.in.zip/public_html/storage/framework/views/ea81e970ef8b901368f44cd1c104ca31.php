<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Customers</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 mt-2 font-weight-bold text-primary">View Customers</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>SL</th>
                        <th>Customer Name</th>
                        <th>Customer Email</th>
                        <th>Customer Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td>
                                <?php if($row->status == 'Active'): ?>
                                    <span class="text-success"><?php echo e($row->status); ?></span>
                                <?php endif; ?>

                                <?php if($row->status == 'Pending'): ?>
                                    <span class="text-danger"><?php echo e($row->status); ?></span>
                                <?php endif; ?>                                
                            </td>
                            <td>
                                <a href="<?php echo e(URL::to('admin/customer/detail/'.$row->id)); ?>" class="btn btn-info btn-sm btn-block" target="_blank">Detail</a>
                                <?php if($row->status == 'Active'): ?>
                                    <a href="<?php echo e(URL::to('admin/customer/make-pending/'.$row->id)); ?>" class="btn btn-secondary btn-sm btn-block" onClick="return confirm('Are you sure?');">Make Pending</a>
                                <?php else: ?>
                                    <a href="<?php echo e(URL::to('admin/customer/make-active/'.$row->id)); ?>" class="btn btn-secondary btn-sm btn-block" onClick="return confirm('Are you sure?');">Make Active</a>
                                <?php endif; ?>
                                <a href="<?php echo e(URL::to('admin/customer/delete/'.$row->id)); ?>" class="btn btn-danger btn-sm btn-block" onClick="return confirm('Are you sure?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/admin/customer/index.blade.php ENDPATH**/ ?>