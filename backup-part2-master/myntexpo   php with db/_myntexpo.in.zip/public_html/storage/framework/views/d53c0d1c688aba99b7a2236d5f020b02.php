<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Edit Admin User Password</h1>

    <form action="<?php echo e(url('admin/role/user/update/password/'.$admin_user->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 mt-2 font-weight-bold text-primary">Edit Admin User Password</h6>
                        <div class="float-right d-inline">
                            <a href="<?php echo e(route('admin.role.user')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> View All</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">New Password *</label>
                            <input type="password" name="password" class="form-control" value="" autofocus>
                        </div>
                        <div class="form-group">
                            <label for="">Retype Password *</label>
                            <input type="password" name="re_password" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/admin/role/user_edit_password.blade.php ENDPATH**/ ?>