<?php $__env->startComponent('mail::message'); ?>
    <?php echo $message; ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/emails/contact_page_message.blade.php ENDPATH**/ ?>