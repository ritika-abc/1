<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_product)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($shop->name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($shop->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content pt_60">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $shop->detail; ?>

                </div>
            </div>
            <div class="row">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="product-item">
                        <div class="photo"><a href="<?php echo e(url('product/'.$row->product_slug)); ?>"><img src="<?php echo e(asset('uploads/'.$row->product_featured_photo)); ?>"></a></div>
                        <div class="text">
                            <h3><a href="<?php echo e(url('product/'.$row->product_slug)); ?>"><?php echo e($row->product_name); ?></a></h3>
                            <div class="price">

                                <?php if($row->product_old_price != ''): ?>
                                <del>$<?php echo e($row->product_old_price); ?></del>
                                <?php endif; ?>

                                $<?php echo e($row->product_current_price); ?>

                            </div>
                            <div class="cart-button">

                                <?php if($row->product_stock == 0): ?>
                                <a href="javascript:void(0);" class="stock-empty w-100-p text-center"><?php echo e(STOCK_EMPTY); ?></a>
                                <?php else: ?>
                                <form action="<?php echo e(route('front.add_to_cart')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($row->id); ?>">
                                    <input type="hidden" name="product_qty" value="1">
                                    <button type="submit"><?php echo e(ADD_TO_CART); ?></button>
                                </form>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-12">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/pages/shop.blade.php ENDPATH**/ ?>