<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_job)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e(JOB_TITLE_COLON); ?> <?php echo e($job_detail->job_title); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($job_detail->job_title); ?></li>
                </ol>
            </nav>
        </div>
    </div>


    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="career-detail">
                        <div class="item">
                            <h3><?php echo e(JOB_TITLE); ?></h3>
                            <p>
                                <?php echo e($job_detail->job_title); ?>

                            </p>
                        </div>
                        <div class="item">
                            <h3><?php echo e(JOB_RESPONSIBILITIES); ?></h3>
                            <?php echo $job_detail->job_responsibility; ?>

                        </div>

                        <div class="item">
                            <h3><?php echo e(EDUCATIONAL_QUALIFICATION); ?></h3>
                            <?php echo $job_detail->job_education; ?>

                        </div>
                        <div class="item">
                            <h3><?php echo e(EXPERIENCE_REQUIREMENT); ?></h3>
                            <?php echo $job_detail->job_experience; ?>

                        </div>
                        <div class="item">
                            <h3><?php echo e(ADDITIONAL_REQUIREMENT); ?></h3>
                            <?php echo $job_detail->job_additional_requirement; ?>

                        </div>
                        <div class="item">
                            <h3><?php echo e(OTHER_BENEFIT); ?></h3>
                            <?php echo $job_detail->job_benefit; ?>

                        </div>
                        <div class="item">
                            <a href="<?php echo e(url('job/apply/'.$job_detail->job_slug)); ?>" class="btn btn-primary btn-arf"><?php echo e(APPLY_NOW); ?></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="career-sidebar">
                        <div class="widget">
                            <h3><?php echo e(ABOUT_THIS_JOB); ?></h3>
                            <div class="career-detail-sidebar">
                                <div class="item">
                                    <h4><?php echo e(VACANCY); ?></h4>
                                    <p><?php echo e($job_detail->job_vacancy); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(COMPANY_NAME); ?></h4>
                                    <p><?php echo e($job_detail->job_company_name); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(JOB_LOCATION); ?></h4>
                                    <p><?php echo e($job_detail->job_location); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(APPLICATION_DEADLINE); ?></h4>
                                    <p><?php echo e($job_detail->job_deadline); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(JOB_TYPE); ?></h4>
                                    <p><?php echo e($job_detail->job_type); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(SALARY); ?></h4>
                                    <p><?php echo e($job_detail->job_salary); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/pages/job.blade.php ENDPATH**/ ?>