<?php $__env->startComponent('mail::message'); ?>
    <?php echo $message; ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/emails/comment_message_to_admin.blade.php ENDPATH**/ ?>