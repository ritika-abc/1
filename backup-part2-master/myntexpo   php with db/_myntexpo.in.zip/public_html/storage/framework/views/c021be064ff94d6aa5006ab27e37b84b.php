<?php echo e($slot); ?>

<?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>