<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_service_detail)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($service_detail->name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('front.services')); ?>"><?php echo e(SERVICES); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($service_detail->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="single-section">
                        <div class="featured-photo">
                            <img src="<?php echo e(asset('uploads/'.$service_detail->photo)); ?>">
                        </div>
                        <div class="text">
                            <h2><?php echo e($service_detail->name); ?></h2>
                            <?php echo $service_detail->description; ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar">
                        <div class="widget">
                            <h3><?php echo e(ALL_SERVICES); ?></h3>
                            <div class="type-2">
                                <ul>
                                    <?php $__currentLoopData = $service_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <img src="<?php echo e(asset('uploads/'.$row->photo)); ?>">
                                        <a href="<?php echo e(url('service/'.$row->slug)); ?>"><?php echo e($row->name); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/pages/service_detail.blade.php ENDPATH**/ ?>