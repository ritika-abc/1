<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_login)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1>Customer Login</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Customer Login</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="reg-login-form">
                        <div class="inner">
                            <form action="<?php echo e(route('customer.login.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="">Email address</label>
                                    <input type="text" class="form-control" name="email">
                                </div>
                                <div class="form-group">
                                    <label for="">Password</label>
                                    <input type="password" class="form-control" name="password">
                                </div>

                                <?php if($g_setting->google_recaptcha_status == 'Show'): ?>
                                <div class="form-group">
                                    <div class="g-recaptcha" data-sitekey="<?php echo e($g_setting->google_recaptcha_site_key); ?>"></div>
                                </div>
                                <?php endif; ?>

                                <button type="submit" class="btn btn-primary btn-arf">Login</button>
                                <a href="<?php echo e(route('customer.forget_password')); ?>" class="btn btn-warning">Forget Password</a>
                                <div class="new-user">
                                    <a href="<?php echo e(route('customer.registration')); ?>">New User? Make Registration</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/customer/auth/login.blade.php ENDPATH**/ ?>