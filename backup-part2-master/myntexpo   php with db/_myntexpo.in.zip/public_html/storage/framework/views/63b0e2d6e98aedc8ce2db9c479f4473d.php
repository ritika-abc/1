<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_project_detail)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($project_detail->project_name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('front.projects')); ?>"><?php echo e(PROJECTS); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($project_detail->project_name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="single-section single-project">

                        <div class="text mt_20">
                            <h2><?php echo e(PROJECT_DETAIL); ?></h2>
                            <p>
                                <img src="<?php echo e(asset('uploads/'.$project_detail->project_featured_photo)); ?>" class="featured-photo">
                            </p>
                            <p>
                                <?php echo $project_detail->project_content; ?>

                            </p>

                            <h2 class="mt_30"><?php echo e(PROJECT_PHOTOS); ?></h2>
                            <div class="project-photo-carousel owl-carousel">

                                <?php $__currentLoopData = $project_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-item">
                                    <div class="p-item-bg"></div>
                                    <a href="<?php echo e(asset('uploads/'.$row->project_photo)); ?>" class="magnific" title="<?php echo e($row->project_photo_caption); ?>">
                                        <img src="<?php echo e(asset('uploads/'.$row->project_photo)); ?>" alt="Project Photo">
                                        <div class="plus-icon">
                                            <i class="fa fa-search-plus"></i>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <h2 class="mt_30"><?php echo e(PROJECT_VIDEO); ?></h2>
                            <div class="iframe-container">
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo e($project_detail->project_video); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="sidebar">

                        <div class="widget">
                            <h3><?php echo e(PROJECT_INFORMATION); ?></h3>
                            <div class="project-detail">
                                <div class="item">
                                    <h4><?php echo e(CLIENT_NAME); ?></h4>
                                    <p><?php echo e($project_detail->project_client_name); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(CLIENT_COMPANY_NAME); ?></h4>
                                    <p><?php echo e($project_detail->project_client_company); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(PROJECT_START_DATE); ?></h4>
                                    <p><?php echo e($project_detail->project_start_date); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(PROJECT_END_DATE); ?></h4>
                                    <p><?php echo e($project_detail->project_end_date); ?></p>
                                </div>
                                <div class="item">
                                    <h4><?php echo e(CLIENT_COMMENT); ?></h4>
                                    <p>
                                        <?php echo nl2br(e($project_detail->project_client_comment)); ?>

                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="widget">
                            <h3><?php echo e(ALL_PROJECTS); ?></h3>
                            <div class="type-2">
                                <ul>
                                    <?php $__currentLoopData = $project_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <img src="<?php echo e(asset('uploads/'.$row->project_featured_photo)); ?>">
                                            <a href="<?php echo e(url('project/'.$row->project_slug)); ?>"><?php echo e($row->project_name); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/pages/project_detail.blade.php ENDPATH**/ ?>