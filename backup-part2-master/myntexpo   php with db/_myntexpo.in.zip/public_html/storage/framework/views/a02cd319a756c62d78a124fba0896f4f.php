<?php
$menus = DB::table('menus')->get();
$menu_arr = array();
?>

<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $menu_arr[$row->menu_name] = $row->menu_status;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Start Navbar Area -->
<div class="navbar-area" id="stickymenu">

    <!-- Menu For Mobile Device -->
    <div class="mobile-nav">
        <a href="" class="logo">
            <img src="<?php echo e(asset('uploads/'.$g_setting->logo)); ?>" alt="">
        </a>
    </div>

    <!-- Menu For Desktop Device -->
    <div class="main-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('uploads/'.$g_setting->logo)); ?>" alt="logo">
                </a>
                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">

                        <?php if($menu_arr['Home'] == 'Show'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/')); ?>" class="nav-link"><?php echo e(MENU_HOME); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if($menu_arr['About'] == 'Show'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('front.about')); ?>" class="nav-link "><?php echo e(MENU_ABOUT); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if($menu_arr['Services'] == 'Show'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('front.services')); ?>" class="nav-link "><?php echo e(MENU_SERVICES); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if($menu_arr['Shop'] == 'Show'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('front.shop')); ?>" class="nav-link "><?php echo e(MENU_SHOP); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if($menu_arr['Blog'] == 'Show'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('front.blogs')); ?>" class="nav-link "><?php echo e(MENU_BLOG); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php
                            $dynamic_pages = DB::table('dynamic_pages')->get();
                        ?>

                        <?php if(
                        ($menu_arr['Career'] == 'Hide') &&
                        ($menu_arr['Project'] == 'Hide') &&
                        ($menu_arr['Photo Gallery'] == 'Hide') &&
                        ($menu_arr['Video Gallery'] == 'Hide') &&
                        ($menu_arr['FAQ'] == 'Hide') &&
                        ($menu_arr['Team Members'] == 'Hide') &&
                        (!$dynamic_pages)
                        ): ?>

                        <?php else: ?>
                        <li class="nav-item">
                            <a href="javascript:void(0);" class="nav-link dropdown-toggle"><?php echo e(MENU_PAGES); ?></a>
                            <ul class="dropdown-menu">

                                <?php if($menu_arr['Career'] == 'Show'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.career')); ?>" class="nav-link"><?php echo e(MENU_CAREER); ?></a>
                                </li>
                                <?php endif; ?>

                                <?php if($menu_arr['Project'] == 'Show'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.projects')); ?>" class="nav-link"><?php echo e(MENU_PROJECTS); ?></a>
                                </li>
                                <?php endif; ?>

                                <?php if($menu_arr['Photo Gallery'] == 'Show'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.photo_gallery')); ?>" class="nav-link"><?php echo e(MENU_PHOTO_GALLERY); ?></a>
                                </li>
                                <?php endif; ?>

                                <?php if($menu_arr['Video Gallery'] == 'Show'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.video_gallery')); ?>" class="nav-link"><?php echo e(MENU_VIDEO_GALLERY); ?></a>
                                </li>
                                <?php endif; ?>

                                <?php if($menu_arr['FAQ'] == 'Show'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.faq')); ?>" class="nav-link"><?php echo e(MENU_FAQ); ?></a>
                                </li>
                                <?php endif; ?>

                                <?php if($menu_arr['Team Members'] == 'Show'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.team_members')); ?>" class="nav-link"><?php echo e(MENU_TEAM_MEMBERS); ?></a>
                                </li>
                                <?php endif; ?>

                                <?php $__currentLoopData = $dynamic_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('page/'.$row->dynamic_page_slug)); ?>" class="nav-link"><?php echo e($row->dynamic_page_name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>
                        <?php endif; ?>


                        <?php if($menu_arr['Contact'] == 'Show'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('front.contact')); ?>" class="nav-link "><?php echo e(MENU_CONTACT); ?></a>
                        </li>
                        <?php endif; ?>

                    </ul>
                </div>
            </nav>
        </div>
    </div>
</div>
<!-- End Navbar Area -->
<?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/layouts/nav.blade.php ENDPATH**/ ?>