<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Edit Sidebar Information</h1>

    <form action="<?php echo e(url('admin/setting/general/sidebar/update')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Sidebar Total Recent Post</label>
                            <input type="text" name="sidebar_total_recent_post" class="form-control" value="<?php echo e($general_setting->sidebar_total_recent_post); ?>">
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/admin/general_setting/sidebar.blade.php ENDPATH**/ ?>