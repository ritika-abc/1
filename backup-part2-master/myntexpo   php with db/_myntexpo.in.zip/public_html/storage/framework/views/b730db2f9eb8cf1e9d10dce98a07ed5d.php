<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Edit Logo</h1>

    <form action="<?php echo e(url('admin/setting/general/logo/update')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="current_photo" value="<?php echo e($general_setting->logo); ?>">

        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="form-group">
                    <label for="">Existing Logo</label>
                    <div>
                        <img src="<?php echo e(asset('uploads/'.$general_setting->logo)); ?>" alt="" class="w_200">
                    </div>
                </div>
                <div class="form-group">
                    <label for="">Change Logo</label>
                    <div>
                        <input type="file" name="logo">
                    </div>
                </div>
                <button type="submit" class="btn btn-success">Update</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/admin/general_setting/logo.blade.php ENDPATH**/ ?>