<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Admin Panel</title>

    <?php echo $__env->make('admin.includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <?php
        $logged_user_role_id = Auth::guard('admin')->user()->role_id;
        $url = Request::path();
        $conName = explode('/',$url);
        ?>

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('admin.dashboard')); ?>">
            <div class="sidebar-brand-text mx-3">Admin Panel</div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">


        <!-- Dashboard -->
        <li class="nav-item <?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="fas fa-fw fa-home"></i>
                <span>Dashboard</span>

            </a>
        </li>

        <?php $arr_one = array(); ?>
        <?php if($logged_user_role_id!=1): ?>
            <?php
                $row = array();
                $access_data = DB::table('role_permissions')
        ->join('role_pages', 'role_permissions.role_page_id', 'role_pages.id')
        ->where('role_id', $logged_user_role_id)
        ->get();
            ?>
            <?php $__currentLoopData = $access_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    if($row->access_status == 1):
                    $arr_one[] = $row->page_title;
                    endif;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


        <?php if($logged_user_role_id!=1): ?>

            <?php if($conName[1] == 'setting'): ?>
                <?php if(!in_array('General Settings', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'page'): ?>
                <?php if(!in_array('Page Settings', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'role'): ?>
                <?php if(!in_array('Admin User Section', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'translation'): ?>
                <?php if(!in_array('Translation Section', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'footer'): ?>
                <?php if(!in_array('Footer Columns', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'slider'): ?>
                <?php if(!in_array('Sliders', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'category'||$conName[1] == 'blog'||$conName[1] == 'comment'): ?>
                <?php if(!in_array('Blog Section', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'dynamic-page'): ?>
                <?php if(!in_array('Dynamic Pages', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'menu'): ?>
                <?php if(!in_array('Menu Manage', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'project'): ?>
                <?php if(!in_array('Project', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'job'): ?>
                <?php if(!in_array('Career Section', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'photo-gallery'): ?>
                <?php if(!in_array('Photo Gallery', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'video-gallery'): ?>
                <?php if(!in_array('Video Gallery', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'product'||$conName[1] == 'shipping'||$conName[1] == 'coupon'): ?>
                <?php if(!in_array('Product Section', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'order'): ?>
                <?php if(!in_array('Order Section', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'customer'): ?>
                <?php if(!in_array('Customer Section', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'why-choose'): ?>
                <?php if(!in_array('Why Choose Us', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'service'): ?>
                <?php if(!in_array('Service', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'testimonial'): ?>
                <?php if(!in_array('Testimonial', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'team-member'): ?>
                <?php if(!in_array('Team Member', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'faq'): ?>
                <?php if(!in_array('FAQ', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'email-template'): ?>
                <?php if(!in_array('Email Template', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'subscriber'): ?>
                <?php if(!in_array('Subscriber Section', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($conName[1] == 'social-media'): ?>
                <?php if(!in_array('Social Media', $arr_one)): ?>
                    <script>window.location = "<?php echo e(url('admin/dashboard')); ?>";</script>
                <?php endif; ?>
            <?php endif; ?>

        <?php endif; ?>



        <!-- General Settings -->
        <?php if( in_array('General Settings', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/setting/general/*') ? 'active' : ''); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSetting" aria-expanded="true" aria-controls="collapseSetting">
                <i class="fas fa-cog"></i>
                <span>General Settings</span>
            </a>
            <div id="collapseSetting" class="collapse <?php echo e(Request::is('admin/setting/general/*') ? 'show' : ''); ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.logo')); ?>">Logo</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.favicon')); ?>">Favicon</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.loginbg')); ?>">Login Background</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.topbar')); ?>">Top Bar</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.banner')); ?>">Banner</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.footer')); ?>">Footer</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.sidebar')); ?>">Sidebar</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.color')); ?>">Color</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.preloader')); ?>">Preloader</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.stickyheader')); ?>">Sticky Header</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.googleanalytic')); ?>">Google Analytic</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.googlerecaptcha')); ?>">Google Recaptcha</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.tawklivechat')); ?>">Tawk Live Chat</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.general_setting.cookieconsent')); ?>">Cookie Consent</a>
                </div>
            </div>
        </li>
        <?php endif; ?>


        <!-- Page Settings -->
        <?php if( in_array('Page Settings', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/page/*') ? 'active' : ''); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePageSettings" aria-expanded="true" aria-controls="collapsePageSettings">
                <i class="fas fa-paste"></i>
                <span>Page Settings</span>
            </a>
            <div id="collapsePageSettings" class="collapse <?php echo e(Request::is('admin/page/*') ? 'show' : ''); ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.page_home.edit')); ?>">Home</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_about.edit')); ?>">About</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_service.edit')); ?>">Service</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_shop.edit')); ?>">Shop</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_blog.edit')); ?>">Blog</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_project.edit')); ?>">Project</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_faq.edit')); ?>">FAQ</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_team.edit')); ?>">Team Member</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_photo_gallery.edit')); ?>">Photo Gallery</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_video_gallery.edit')); ?>">Video Gallery</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_contact.edit')); ?>">Contact</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_career.edit')); ?>">Career</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_term.edit')); ?>">Term</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_privacy.edit')); ?>">Privacy</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.page_other.edit')); ?>">Other</a>
                </div>
            </div>
        </li>
        <?php endif; ?>



        <!-- Admin Users Section -->
        <?php if( in_array('Admin User Section', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/role/*') ? 'active' : ''); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseAdminUser" aria-expanded="true" aria-controls="collapseAdminUser">
                <i class="fas fa-user-secret"></i>
                <span>Admin User Section</span>
            </a>
            <div id="collapseAdminUser" class="collapse <?php echo e(Request::is('admin/role/*') ? 'show' : ''); ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.role.index')); ?>">Roles</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.role.user')); ?>">Users</a>
                </div>
            </div>
        </li>
        <?php endif; ?>



        <!-- Translation Section -->
        <?php if( in_array('Translation Section', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/translation/front/*') ? 'active' : ''); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTranslation" aria-expanded="true" aria-controls="collapseTranslation">
                <i class="fas fa-user-secret"></i>
                <span>Translation Section</span>
            </a>
            <div id="collapseTranslation" class="collapse <?php echo e(Request::is('admin/translation/front/*') ? 'show' : ''); ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.translation.front')); ?>">Front End</a>
                </div>
            </div>
        </li>
        <?php endif; ?>



        <!-- Footer Columns -->
        <?php if( in_array('Footer Columns', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/footer/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.footer.index')); ?>">
                <i class="fas fa-fw fa-list-alt"></i>
                <span>Footer Columns</span>
            </a>
        </li>
        <?php endif; ?>




        <!-- Sliders -->
        <?php if( in_array('Sliders', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/slider/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.slider.index')); ?>">
                <i class="fas fa-sliders-h"></i>
                <span>Sliders</span>
            </a>
        </li>
        <?php endif; ?>



        <!-- Blog Section -->
        <?php if( in_array('Blog Section', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/category/*')||Request::is('admin/blog/*')||Request::is('admin/comment/*') ? 'active' : ''); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBlog" aria-expanded="true" aria-controls="collapseBlog">
                <i class="fas fa-cubes"></i>
                <span>Blog Section</span>
            </a>
            <div id="collapseBlog" class="collapse <?php echo e(Request::is('admin/category/*')||Request::is('admin/blog/*')||Request::is('admin/comment/*') ? 'show' : ''); ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.category.index')); ?>">Categories</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.blog.index')); ?>">Blogs</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.comment.approved')); ?>">Approved Comments</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.comment.pending')); ?>">Pending Comments</a>
                </div>
            </div>
        </li>
        <?php endif; ?>



        <!-- Dynamic Pages -->
        <?php if( in_array('Dynamic Pages', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/dynamic-page/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.dynamic_page.index')); ?>">
                <i class="fas fa-cube"></i>
                <span>Dynamic Pages</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Menu Manage -->
        <?php if( in_array('Menu Manage', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/menu/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.menu.index')); ?>">
                <i class="fas fa-bars"></i>
                <span>Menu Manage</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Project -->
        <?php if( in_array('Project', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/project/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.project.index')); ?>">
                <i class="fas fa-umbrella"></i>
                <span>Project</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Career Section -->
        <?php if( in_array('Career Section', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/job/*') ? 'active' : ''); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCareer" aria-expanded="true" aria-controls="collapseCareer">
                <i class="fas fa-user-secret"></i>
                <span>Career Section</span>
            </a>
            <div id="collapseCareer" class="collapse <?php echo e(Request::is('admin/job/*') ? 'show' : ''); ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.job.index')); ?>">Jobs</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.job.view_application')); ?>">Job Applications</a>
                </div>
            </div>
        </li>
        <?php endif; ?>


        <!-- Photo Gallery -->
        <?php if( in_array('Photo Gallery', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/photo-gallery/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.photo.index')); ?>">
                <i class="fas fa-camera"></i>
                <span>Photo Gallery</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Video Gallery -->
        <?php if( in_array('Video Gallery', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/video-gallery/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.video.index')); ?>">
                <i class="fas fa-video"></i>
                <span>Video Gallery</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Product Section -->
        <?php if( in_array('Product Section', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/product/*')||Request::is('admin/shipping/*')||Request::is('admin/coupon/*') ? 'active' : ''); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseProduct" aria-expanded="true" aria-controls="collapseProduct">
                <i class="fas fa-shopping-cart"></i>
                <span>Product Section</span>
            </a>
            <div id="collapseProduct" class="collapse <?php echo e(Request::is('admin/product/*')||Request::is('admin/shipping/*')||Request::is('admin/coupon/*') ? 'show' : ''); ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.product.index')); ?>">Product</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.shipping.index')); ?>">Shipping</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.coupon.index')); ?>">coupon</a>
                </div>
            </div>
        </li>
        <?php endif; ?>

        <!-- Order -->
        <?php if( in_array('Order Section', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/order/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.order.index')); ?>">
                <i class="fas fa-bookmark"></i>
                <span>Order Section</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Customer -->
        <?php if( in_array('Customer Section', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/customer/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.customer.index')); ?>">
                <i class="fas fa-users"></i>
                <span>Customer Section</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Why Choose Us -->
        <?php if( in_array('Why Choose Us', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/why-choose/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.why_choose.index')); ?>">
                <i class="fas fa-arrows-alt"></i>
                <span>Why Choose Us</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Services -->
        <?php if( in_array('Service', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/service/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.service.index')); ?>">
                <i class="fas fa-certificate"></i>
                <span>Service</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Testimonials -->
        <?php if( in_array('Testimonial', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/testimonial/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.testimonial.index')); ?>">
                <i class="fas fa-award"></i>
                <span>Testimonial</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Team Members -->
        <?php if( in_array('Team Member', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/team-member/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.team_member.index')); ?>">
                <i class="fas fa-user-plus"></i>
                <span>Team Member</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- FAQ -->
        <?php if( in_array('FAQ', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/faq/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.faq.index')); ?>">
                <i class="fas fa-question-circle"></i>
                <span>FAQ</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Email Template -->
        <?php if( in_array('Email Template', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/email-template/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.email_template.index')); ?>">
                <i class="fas fa-envelope"></i>
                <span>Email Template</span>
            </a>
        </li>
        <?php endif; ?>

        <!-- Subscriber -->
        <?php if( in_array('Subscriber Section', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/subscriber/*') ? 'active' : ''); ?>">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSubscriber" aria-expanded="true" aria-controls="collapseSubscriber">
                <i class="fas fa-share-alt-square"></i>
                <span>Subscriber Section</span>
            </a>
            <div id="collapseSubscriber" class="collapse <?php echo e(Request::is('admin/subscriber/*') ? 'show' : ''); ?>" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="<?php echo e(route('admin.subscriber.index')); ?>">All Subscribers</a>
                    <a class="collapse-item" href="<?php echo e(route('admin.subscriber.send_email')); ?>">Send Email to Subscribers</a>
                </div>
            </div>
        </li>
        <?php endif; ?>

        <!-- Social Media -->
        <?php if( in_array('Social Media', $arr_one) || $logged_user_role_id==1 ): ?>
        <li class="nav-item <?php echo e(Request::is('admin/social-media/*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.social_media.index')); ?>">
                <i class="fas fa-basketball-ball"></i>
                <span>Social Media</span>
            </a>
        </li>
        <?php endif; ?>


        <!-- Divider -->
        <hr class="sidebar-divider">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>
    </ul>
    <!-- End of Sidebar -->


    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">


                    <!-- Nav Item - Alerts -->
                    <li class="nav-item dropdown no-arrow mx-1">
                        <a class="btn btn-info btn-sm mt-3" href="<?php echo e(url('/')); ?>" target="_blank">
                            Visit Website
                        </a>
                    </li>

                    <div class="topbar-divider d-none d-sm-block"></div>
                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::guard('admin')->user()->name); ?></span>
                            <img class="img-profile rounded-circle" src="<?php echo e(asset('uploads/'.Auth::guard('admin')->user()->photo)); ?>">
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

                            <?php if(Auth::guard('admin')->user()->id == 1): ?>
                            <a class="dropdown-item" href="<?php echo e(route('admin.profile_change')); ?>">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i> Change Profile
                            </a>
                            <?php endif; ?>

                            <a class="dropdown-item" href="<?php echo e(route('admin.password_change')); ?>">
                                <i class="fas fa-unlock-alt fa-sm fa-fw mr-2 text-gray-400"></i> Change Password
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.photo_change')); ?>">
                                <i class="fas fa-image fa-sm fa-fw mr-2 text-gray-400"></i> Change Photo
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Logout
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
            <!-- End of Topbar -->
            <!-- Begin Page Content -->
            <div class="container-fluid">

                <?php echo $__env->yieldContent('admin_content'); ?>

            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- End of Main Content -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php echo $__env->make('admin.includes.scripts-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH /home/u496524825/domains/myntexpo.in/public_html/resources/views/admin/admin_layouts.blade.php ENDPATH**/ ?>