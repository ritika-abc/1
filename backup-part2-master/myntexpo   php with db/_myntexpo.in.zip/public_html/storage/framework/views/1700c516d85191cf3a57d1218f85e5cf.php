<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_contact)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($contact->name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($contact->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $contact->detail; ?>

                </div>
            </div>
            <div class="row">

                <?php if($contact->contact_address!=null): ?>
                <div class="col-md-4">
                    <div class="contact-item flex">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                        </div>
                        <div class="contact-text">
                            <h4><?php echo e(ADDRESS); ?></h4>
                            <p>
                                <?php echo nl2br(e($contact->contact_address)); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($contact->contact_phone!=null): ?>
                <div class="col-md-4">
                    <div class="contact-item flex">
                        <div class="contact-icon">
                            <i class="fas fa-phone-volume" aria-hidden="true"></i>
                        </div>
                        <div class="contact-text">
                            <h4><?php echo e(PHONE); ?></h4>
                            <p>
                                <?php echo nl2br(e($contact->contact_phone)); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($contact->contact_email!=null): ?>
                <div class="col-md-4">
                    <div class="contact-item flex">
                        <div class="contact-icon">
                            <i class="fas fa-envelope-open" aria-hidden="true"></i>
                        </div>
                        <div class="contact-text">
                            <h4><?php echo e(EMAIL_ADDRESS); ?></h4>
                            <p>
                                <?php echo nl2br(e($contact->contact_email)); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="row contact-form">
                <div class="col-md-12">
                    <h4 class="contact-form-title mt_50 mb_20"><?php echo e(CONTACT_FORM); ?></h4>
                    <form action="<?php echo e(route('front.contact_form')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo e(NAME); ?> (<?php echo e(REQUIRED); ?>)</label>
                                    <input type="text" class="form-control" name="visitor_name">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo e(EMAIL_ADDRESS); ?> (<?php echo e(REQUIRED); ?>)</label>
                                    <input type="email" class="form-control" name="visitor_email">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo e(PHONE); ?></label>
                                    <input type="text" class="form-control" name="visitor_phone">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(MESSAGE); ?> (<?php echo e(REQUIRED); ?>)</label>
                            <textarea name="visitor_message" class="form-control h-200" cols="30" rows="10"></textarea>
                        </div>

                        <?php if($g_setting->google_recaptcha_status == 'Show'): ?>
                        <div class="form-group">
                            <div class="g-recaptcha" data-sitekey="<?php echo e($g_setting->google_recaptcha_site_key); ?>"></div>
                        </div>
                        <?php endif; ?>

                        <button type="submit" class="btn btn-primary mt_10"><?php echo e(SEND_MESSAGE); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/pages/contact.blade.php ENDPATH**/ ?>