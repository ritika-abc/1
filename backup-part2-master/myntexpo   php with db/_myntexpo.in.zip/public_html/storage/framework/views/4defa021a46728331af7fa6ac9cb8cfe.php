<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_career)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($career->name); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($career->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>


    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $career->detail; ?>

                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="career">

                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="career-main-item">
                            <h3><?php echo e($row->job_title); ?></h3>
                            <h4><?php echo e(COMPANY_COLON); ?> <?php echo e($row->job_company_name); ?> | <?php echo e(DEADLINE_COLON); ?> <?php echo e($row->job_deadline); ?></h4>
                            <p>
                                <?php echo nl2br(e($row->job_description_short)); ?>

                            </p>
                            <div class="row long">
                                <div class="col-md-4">
                                    <div class="btn btn-secondary btn-sm btn-block"><i class="fa fa-map-marker"></i> <?php echo e($row->job_location); ?></div>
                                </div>
                                <div class="col-md-4">
                                    <a href="<?php echo e(url('job/'.$row->job_slug)); ?>" class="btn btn-success btn-sm btn-block"><?php echo e(SEE_DETAIL); ?></a>
                                </div>
                                <div class="col-md-4">
                                    <a href="<?php echo e(url('job/apply/'.$row->job_slug)); ?>" class="btn btn-danger btn-sm btn-block"><?php echo e(APPLY_NOW); ?></a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/pages/career.blade.php ENDPATH**/ ?>