<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Edit Admin User</h1>

    <form action="<?php echo e(url('admin/role/user/update/'.$admin_user->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="current_photo" value="<?php echo e($admin_user->photo); ?>">
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 mt-2 font-weight-bold text-primary">Edit Admin User</h6>
                        <div class="float-right d-inline">
                            <a href="<?php echo e(route('admin.role.user')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> View All</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Name *</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($admin_user->name); ?>" autofocus>
                        </div>
                        <div class="form-group">
                            <label for="">Email *</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e($admin_user->email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Existing Photo</label>
                            <div>
                                <img src="<?php echo e(asset('uploads/'.$admin_user->photo)); ?>" alt="" class="w_200">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Change Photo</label>
                            <div>
                                <input type="file" name="photo">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Select Role *</label>
                            <select name="role_id" class="form-control">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($row->role_name == 'Super Admin'): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                    <option value="<?php echo e($row->id); ?>" <?php if($row->id == $admin_user->role_id): ?> selected <?php endif; ?>><?php echo e($row->role_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/admin/role/user_edit.blade.php ENDPATH**/ ?>