<link rel="stylesheet" href="<?php echo e(asset('backend/vendor/fontawesome-free/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/sb-admin-2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/jquery-ui.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/jquery.timepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/summernote-bs4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/spacing.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/css/style.css')); ?>">

<link href="https://fonts.googleapis.com/css2?family=Sen:wght@400;700&display=swap" rel="stylesheet"><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/admin/includes/styles.blade.php ENDPATH**/ ?>