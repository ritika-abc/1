<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_blog_detail)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e($blog_detail->blog_title); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('front.blogs')); ?>"><?php echo e(BLOGS); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($blog_detail->blog_title); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="single-section">
                        <div class="featured-photo">
                            <img src="<?php echo e(asset('uploads/'.$blog_detail->blog_photo)); ?>">
                        </div>
                        <div class="text">
                            <h2><?php echo e($blog_detail->blog_title); ?></h2>
                            <h3>
                                <?php echo e(POSTED_ON); ?> <?php echo e(\Carbon\Carbon::parse($blog_detail->created_at)->format('d M, Y')); ?>

                            </h3>
                            <?php echo $blog_detail->blog_content; ?>

                        </div>

                        <h2 class="mt_35"><?php echo e(SHARE_THIS); ?></h2>
                        <div class="share_buttons">
                            <a class="facebook" target="_blank" href="http://www.facebook.com/sharer.php?u=<?php echo e(url('blog/'.$blog_detail->blog_slug)); ?>&t=<?php echo e($blog_detail->blog_title); ?>"><i class="fab fa-facebook-f"></i></a>

                            <a class="twitter" target="_blank" href="https://twitter.com/share?text=<?php echo e($blog_detail->blog_title); ?>&url=<?php echo e(url('blog/'.$blog_detail->blog_slug)); ?>"><i class="fab fa-twitter"></i></a>

                            <a class="pinterest" target="_blank" href="https://www.pinterest.com/pin/create/button/?description=<?php echo e($blog_detail->blog_title); ?>&media=&url=<?php echo e(url('blog/'.$blog_detail->blog_slug)); ?>"><i class="fab fa-pinterest"></i></a>

                            <a class="linkedin" target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(url('blog/'.$blog_detail->blog_slug)); ?>&title=<?php echo e($blog_detail->blog_title); ?>"><i class="fab fa-linkedin-in"></i></a>
                        </div>


                        <!-- Comment Section Started -->
                        <hr class="mt_50">
                        <div class="comment mt_50">

                            <h2 class="mb_40"><?php echo e(COMMENTS); ?> (<?php echo e(count($comments)); ?>)</h2>

                            <?php if(count($comments) == 0): ?>
                                <div class="text-danger"><?php echo e(NO_COMMENT_FOUND); ?></div>
                            <?php else: ?>
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="comment-item">
                                        <div class="text">
                                            <h4><?php echo e($loop->iteration . '. ' . $row->person_name); ?></h4>
                                            <div class="date"><?php echo e(\Carbon\Carbon::parse($row->created_at)->format('d M, Y')); ?></div>
                                            <div class="des">
                                                <p>
                                                    <?php echo nl2br(e($row->person_message)); ?>

                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <hr class="mt_50">

                            <h2 class="mt_35"><?php echo e(POST_YOUR_COMMENT); ?></h2>
                            <form action="<?php echo e(route('front.comment')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="blog_id" value="<?php echo e($blog_detail->id); ?>">
                                <input type="hidden" name="blog_slug" value="<?php echo e($blog_detail->blog_slug); ?>">
                                <input type="hidden" name="comment_status" value="Pending">
                                <div class="row mb_20">
                                    <div class="col">
                                        <input type="text" class="form-control" placeholder="<?php echo e(NAME); ?>" name="person_name">
                                    </div>
                                    <div class="col">
                                        <input type="email" class="form-control" placeholder="<?php echo e(EMAIL_ADDRESS); ?>" name="person_email">
                                    </div>
                                </div>
                                <div class="row mb_20">
                                    <div class="col">
                                        <textarea name="person_message" class="form-control h-200" cols="30" rows="10" placeholder="<?php echo e(COMMENT); ?>"></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <button type="submit" class="btn btn-primary"><?php echo e(POST_COMMENT); ?></button>
                                    </div>
                                </div>
                            </form>

                        </div>
                        <!-- Comment Section End -->



                    </div>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('layouts.sidebar_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/pages/blog_detail.blade.php ENDPATH**/ ?>