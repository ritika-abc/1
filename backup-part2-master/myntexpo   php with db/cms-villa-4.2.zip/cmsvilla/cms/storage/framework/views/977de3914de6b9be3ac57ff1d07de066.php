<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Setup Roles for <?php echo e($role->role_name); ?></h1>

    <form action="<?php echo e(url('admin/role/access-setup-update/'.$role->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 mt-2 font-weight-bold text-primary">Setup Roles for <?php echo e($role->role_name); ?></h6>
                        <div class="float-right d-inline">
                            <a href="<?php echo e(route('admin.role.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> View All</a>
                        </div>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered">

                        <?php $i=0; ?>
                        <?php $__currentLoopData = $role_permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="role_permission_ids[<?php echo $i; ?>]" value="<?php echo e($row->id); ?>">
                            <input type="hidden" name="access_status_arr[<?php echo $i; ?>]" value="0">

                            <tr>
                                <td class="w_50">
                                    <input type="checkbox" name="access_status_arr[<?php echo $i; ?>]" value="1" <?php if($row->access_status == 1): ?> <?php echo 'checked'; ?> <?php endif; ?>>
                                </td>
                                <td>
                                    <?php
                                        $role_page_data = DB::table('role_pages')->where('id', $row->role_page_id)->first();
                                    ?>

                                    <?php echo e($role_page_data->page_title); ?>

                                </td>
                            </tr>
                            <?php $i++; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>

                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/admin/role/access_setup.blade.php ENDPATH**/ ?>