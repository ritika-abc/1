<?php $__env->startSection('content'); ?>
    <div class="page-banner" style="background-image: url(<?php echo e(asset('uploads/'.$g_setting->banner_cart)); ?>)">
        <div class="bg-page"></div>
        <div class="text">
            <h1><?php echo e(CART); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(HOME); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(CART); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="page-content pt_50 pb_60">
        <div class="container">
            <div class="row cart">
                <div class="col-md-12">
                    <?php if(Session::has('cart_product_id')): ?>
                    <form action="<?php echo e(url('cart/update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                <tr class="table-info">
                                    <th><?php echo e(SERIAL); ?></th>
                                    <th><?php echo e(THUMBNAIL); ?></th>
                                    <th><?php echo e(PRODUCT_NAME); ?></th>
                                    <th><?php echo e(UNIT_PRICE); ?></th>
                                    <th><?php echo e(QUANTITY); ?></th>
                                    <th><?php echo e(SUB_TOTAL); ?></th>
                                    <th><?php echo e(ACTION); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $value = '';
                                    $itm = '';
                                    $arr_cart_product_id = array();
                                    $arr_cart_product_qty = array();
                                    $subtotal = 0;
                                ?>
                                <?php $i=0 ?>
                                <?php $__currentLoopData = Session::get('cart_product_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $i++;
                                        $arr_cart_product_id[$i] = $value;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php $i=0 ?>
                                <?php $__currentLoopData = Session::get('cart_product_qty'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $i++;
                                        $arr_cart_product_qty[$i] = $value;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php $tot1 = 0 ?>
                                <?php for($i=1;$i<=count($arr_cart_product_id);$i++): ?>

                                    <?php
                                        $all_data = DB::table('products')->where('id', $arr_cart_product_id[$i])->get();
                                    ?>

                                    <?php $__currentLoopData = $all_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $product_name = $itm->product_name;
                                            $product_slug = $itm->product_slug;
                                            $product_current_price = $itm->product_current_price;
                                            $product_featured_photo = $itm->product_featured_photo;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <input type="hidden" name="product_id[]" value="<?php echo e($arr_cart_product_id[$i]); ?>">
                                    <tr>
                                        <td class="align-middle"><?php echo e($i); ?></td>
                                        <td class="align-middle"><img src="<?php echo e(asset('uploads/'.$product_featured_photo)); ?>"></td>
                                        <td class="align-middle">
                                            <a href="<?php echo e(url('product/'.$product_slug)); ?>"><?php echo e($product_name); ?></a>
                                        </td>
                                        <td class="align-middle">$<?php echo e($product_current_price); ?></td>
                                        <td class="align-middle">
                                            <input type="number" class="form-control" name="product_qty[]" step="1" min="1" max="" pattern="" pattern="[0-9]*" inputmode="numeric" value="<?php echo e($arr_cart_product_qty[$i]); ?>">
                                        </td>
                                        <td class="align-middle">
                                            $<?php echo e($subtotal = $product_current_price * $arr_cart_product_qty[$i]); ?>

                                        </td>
                                        <td class="align-middle">
                                        <a href="<?php echo e(url('cart/delete/'.$arr_cart_product_id[$i])); ?>" class="cart_button_arefin btn btn-xs btn-danger" onClick="return confirm('<?php echo e(ARE_YOU_SURE); ?>');"><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>

                                    <?php $tot1 = $tot1 + $subtotal; ?>
                                <?php endfor; ?>

                                <tr>
                                    <td colspan="5" class="text-right"><?php echo e(TOTAL); ?> </td>
                                    <td colspan="2">$<span class="update_subtotal"><?php echo e($tot1); ?></span></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="cart-buttons">
                            <a href="<?php echo e(route('front.shop')); ?>" class="btn btn-info btn-arf"><?php echo e(CONTINUE_SHOPPING); ?></a>
                            <input type="submit" value="<?php echo e(UPDATE_CART); ?>" class="btn btn-info btn-arf" name="form1">
                            <a href="<?php echo e(route('front.checkout')); ?>" class="btn btn-info btn-arf"><?php echo e(CHECKOUT); ?></a>
                        </div>
                    </form>

                    <?php else: ?>
                        <?php echo e(CART_EMPTY); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/pages/cart.blade.php ENDPATH**/ ?>