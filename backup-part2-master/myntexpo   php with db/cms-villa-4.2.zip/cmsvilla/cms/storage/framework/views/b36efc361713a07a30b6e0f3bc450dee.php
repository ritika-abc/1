<?php $__env->startSection('admin_content'); ?>
    <h1 class="h3 mb-3 text-gray-800">Edit Login Background</h1>

    <form action="<?php echo e(url('admin/setting/general/loginbg/update')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="current_photo" value="<?php echo e($general_setting->login_bg); ?>">

        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="form-group">
                    <label for="">Existing Favicon</label>
                    <div>
                        <img src="<?php echo e(asset('uploads/'.$general_setting->login_bg)); ?>" alt="" class="w_300">
                    </div>
                </div>
                <div class="form-group">
                    <label for="">Change Favicon</label>
                    <div>
                        <input type="file" name="login_bg">
                    </div>
                </div>
                <button type="submit" class="btn btn-success">Update</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/admin/general_setting/loginbg.blade.php ENDPATH**/ ?>