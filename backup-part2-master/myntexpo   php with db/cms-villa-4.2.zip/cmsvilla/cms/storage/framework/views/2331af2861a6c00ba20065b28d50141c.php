[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>