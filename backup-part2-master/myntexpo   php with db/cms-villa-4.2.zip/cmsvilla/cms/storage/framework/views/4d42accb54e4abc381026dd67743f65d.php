<?php echo e($slot); ?>

<?php /**PATH /Applications/MAMP/htdocs/phpscriptpoint/cmsvilla/cmsvilla/cms/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>