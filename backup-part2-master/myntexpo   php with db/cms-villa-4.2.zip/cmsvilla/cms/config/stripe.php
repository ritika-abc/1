<?php
return [
    'stripe_pk' => env('STRIPE_PUBLISHABLE_KEY'),
    'stripe_sk' => env('STRIPE_SECRET_KEY')
];