<?php
$servername = "127.0.0.1:3306";
$username = " u496524825_Gold";
$password = "Ajay@1234#";
$dbname = " u496524825_Gold";
// Create connection
$conn = mysqli_connect("127.0.0.1:3306","u496524825_Gold","Ajay@1234#","u496524825_Gold");
?>
