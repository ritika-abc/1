 <div class="container">
     <br>
     <h1 class="text-center">Our Certificates</h1><hr>
  <div class="row">
   <div class="about_top clearfix">
    <div class="col-sm-6 about_top_left clearfix">
        <embed src="certificate/45a1e67c-f1af-4b56-bfd0-620a5a1ce0da" type="application/pdf" width="100%" height="700px">
    </div>  
    <div class="col-sm-6 about_top_left clearfix">
          <embed src="certificate/255baf2b-6e38-4c6b-9e7b-14746675d12f" type="application/pdf" width="100%" height="700px">
    </div>
    </div>
    </div>
    
     <div class="row">
   <div class="about_top clearfix">
    <div class="col-sm-6 about_top_left clearfix">
          <embed src="certificate/4759601c-c6c9-4b26-8591-afdd753a0cd3" type="application/pdf" width="100%" height="700px">
    </div>  
    <div class="col-sm-6 about_top_left clearfix">
         <embed src="certificate/e82d7507-1433-468b-825b-40e096ece162" type="application/pdf" width="100%" height="700px">
    </div>
    </div>
    </div>
      </div>