<section id="center_1" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="center_1_top clearfix">
     <ul>
	  <li><i class="fa fa-edit"></i><span class="boost_1">Customization for Individuality</span><span class="boost_2"></span></li>
	  <li><i class="fa fa-certificate"></i><span class="boost_1">Quality Assurance</span><span class="boost_2"></span></li>
	  <li><i class="fa fa-retweet"></i><span class="boost_1">Exclusivity and Limited Editions</span><span class="boost_2"></span></li>
	  <li><i class="fa fa-life-saver"></i><span class="boost_1">Global Collaboration</span><span class="boost_2"></span></li>
	 </ul>
   </div>
  </div>
 </div>
</section>
