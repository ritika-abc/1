<section id="center_7" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="center_7_top clearfix">
    <div class="center_7_top_inner_1 clearfix">
	 <h2>FOLLOW US</h2>
	 <h5>Join Us & Save more on your favourite products</h5>
	 <hr class="hr_2">
	  <ul>
	   <li><a class="family_1" href="#"><i class="fa fa-facebook-f"></i>facebook</a></li>
	   <li><a class="family_2" href="#"><i class="fa fa-twitter"></i>twitter</a></li>
	   <li><a class="family_3" href="#"><i class="fa fa-instagram"></i>instagram</a></li>
	   <li><a class="family_4" href="#"><i class="fa fa-pinterest-p"></i>pinterest</a></li>
	  </ul>
	</div>
   </div>
  </div>
 </div>
</section>
