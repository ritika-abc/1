<section id="center_2" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="center_2_top clearfix">
     <h2>View Our Products</h2>
	 <hr class="hr_1">
   </div>
   <div class="center_2_top_2 clearfix">
    <div class="col-sm-3 center_2_top_2_left clearfix">
	 <div class="center_2_top_2_left_inner animated slideInLeft clearfix card">
	   <a href="product.php?category=bags"><img src="image/bag.jpeg" width="100%">
	   <div class="centered">
	   	   	    <button class="quote">Manufactued Bags</button>
	   </div>
	   </a>
	 </div>
	</div>
	<div class="col-sm-3 center_2_top_2_left clearfix">
	 <div class="center_2_top_2_left_inner clearfix card">
	  <a href="product.php?category=HOME%20IMPROVEMENT"><img src="image/Dinnerware.jpg" width="100%">
	  	   <div class="centered">
	  	   	   	    <button class="quote">SUSTAINABLE TABLEWARE</button>
	  	   </div>
</a>
	 </div>
	</div>
	<div class="col-sm-3 center_2_top_2_left clearfix">
	 <div class="center_2_top_2_left_inner clearfix card">
	   <p><a href="#"><img src="image/Home-Improve-1.jpg" width="100%">
	    <div class="centered">
	    	   	    <button class="quote">HOME IMPROVEMENT</button>
	    </div>
	   
	   </a></p>
	 </div>
	</div>
	<div class="col-sm-3 center_2_top_2_left clearfix">
	 <div class="center_2_top_2_left_inner clearfix card">
	   <p><a href="#"><img src="image/Unique-1.jpg" width="100%">
	   	    <div class="centered">
	   	    <button class="quote">Unique Products</button>
	   	    </div>
</a></p>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>
